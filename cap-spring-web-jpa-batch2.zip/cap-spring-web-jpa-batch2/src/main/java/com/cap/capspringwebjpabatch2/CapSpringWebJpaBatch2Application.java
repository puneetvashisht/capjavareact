package com.cap.capspringwebjpabatch2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapSpringWebJpaBatch2Application {

	public static void main(String[] args) {
		SpringApplication.run(CapSpringWebJpaBatch2Application.class, args);
	}

}
